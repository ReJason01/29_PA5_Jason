﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public float MovementSpeed;

    private Rigidbody rb = null;
    private Vector3 moveDirection = Vector3.zero;
    [SerializeField] int score;
    [SerializeField] int scoretowin;
    [SerializeField] Text txt;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }
    // Update is called once per frame
    void Update()
    {
        UpdateMovement();
        UpdateRotation();
    }
    private void UpdateMovement()
    {
        txt.text = "Score : " + score.ToString();
        if(score >= scoretowin)
        {
            Scene scene = SceneManager.GetActiveScene();
            if (scene.name == "Level1Maze")
            {
                SceneManager.LoadScene("S2");
            }
            else if(scene.name == "S2")
            {
                SceneManager.LoadScene("GameWin");
            }
        }
        // Get the direction based on the user input
        moveDirection = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));
        moveDirection.Normalize();

        // Set the velocity to the direction * movement speed
        rb.velocity = new Vector3(moveDirection.x * MovementSpeed, rb.velocity.y, moveDirection.z * MovementSpeed);
    }
    private void UpdateRotation()
    {
        // The step size is dependent on the delta time.
        float step = MovementSpeed * 3 * Time.deltaTime;
        Vector3 newDir = Vector3.RotateTowards(transform.forward, moveDirection, step, 0.0f);

        // Rotate our position a step closer to the target.
        transform.rotation = Quaternion.LookRotation(newDir);
    }
    private void OnCollisionEnter(Collision collision)
    {

        if (collision.gameObject.tag == "Coins")
        {

            score += 1;
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.tag == "Danger")
        {
            SceneManager.LoadScene("GameLose");
        }
    }
}   
